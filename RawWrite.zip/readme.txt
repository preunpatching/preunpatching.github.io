RawWrite for Windows Readme
---------------------------
This is a new revision of chrysocome.net's project "RawWrite", which is a utility used to write and
read floppy disks.

But, what's so special about it?

VERSION 1.0!!!!!!!!!!

- Compiled with Borland Delphi 7
- Fixed grammatical errors
- Removed non-working and useless functions
- Added new code
- Uses the old Total Commander icon

For Windows 95, Windows 98 and Windows ME, it needs diskio.dll. Otherwise it will not work.