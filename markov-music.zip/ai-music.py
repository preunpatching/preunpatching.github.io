import pickle
import random
import os
import glob
from collections import defaultdict
from tqdm import tqdm, trange
import mido

# --- Constants for your Tokenizer ---
TOK_START = 128      # <generation start>
TOK_END = 129        # <generation end>
TOK_SKIP = 130       # <skip>
TOK_INSTR = 131      # <switch instrument>
MAX_INT_VAL = 16384  # Max value for 14-bit integer (128*128)

def ms_to_tokens(ms):
    """Converts milliseconds to High/Low 7-bit tokens."""
    ms = max(1, min(ms, MAX_INT_VAL)) # Clamp to 1-16384
    return [ms // 128, ms % 128]

def tokens_to_ms(high, low):
    """Converts High/Low 7-bit tokens back to milliseconds."""
    return (high * 128) + low

def parse_midi_to_tokens(filepath, track_id):
    """
    Parses a MIDI file into the specified token sequence:
    <start> <id> <notes...> <skip> ... <end>
    """
    try:
        mid = mido.MidiFile(filepath)
    except Exception as e:
        print(f"Skipping {filepath}: {e}")
        return []

    # 1. Flatten all tracks into a single list of absolute-time events
    # We need to convert ticks to milliseconds.
    events = [] # (time_in_ms, type, data)
    
    # We need to calculate absolute time in MS. 
    # Mido's standard iteration doesn't easily give absolute MS for overlapping notes across tracks,
    # so we'll do a manual pass.
    
    # Merge tracks to handle simultaneous events across tracks correctly
    merged_msgs = mido.merge_tracks(mid.tracks)
    
    current_time_ms = 0
    tempo = 500000 # Default MIDI tempo (120 BPM)
    active_notes = {} # (channel, note) -> start_time_ms
    
    # Current instrument per channel (default to 0)
    current_programs = {i: 0 for i in range(16)}

    for msg in merged_msgs:
        # Update time
        time_delta_sec = mido.tick2second(msg.time, mid.ticks_per_beat, tempo)
        current_time_ms += int(time_delta_sec * 1000)

        if msg.type == 'set_tempo':
            tempo = msg.tempo
        
        elif msg.type == 'program_change':
            if msg.channel != 9: # Ignore percussion channel 10 (index 9)
                events.append({
                    'time': current_time_ms,
                    'type': 'instr',
                    'data': msg.program,
                    'channel': msg.channel
                })
        
        elif msg.type == 'note_on' and msg.velocity > 0:
            if msg.channel != 9:
                key = (msg.channel, msg.note)
                active_notes[key] = current_time_ms
        
        elif (msg.type == 'note_off') or (msg.type == 'note_on' and msg.velocity == 0):
            if msg.channel != 9:
                key = (msg.channel, msg.note)
                if key in active_notes:
                    start_ms = active_notes.pop(key)
                    duration = current_time_ms - start_ms
                    if duration > 0:
                        events.append({
                            'time': start_ms,
                            'type': 'note',
                            'note': msg.note,
                            'duration': duration,
                            'channel': msg.channel
                        })

    # Sort events by time. If times are equal, put instrument changes before notes.
    events.sort(key=lambda x: (x['time'], 0 if x['type'] == 'instr' else 1))

    # 2. Build Token Sequence
    tokens = [TOK_START, track_id]
    
    last_time = 0
    last_instr = -1 # Keep track to avoid redundant switches

    for event in events:
        # Calculate Skip
        dt = event['time'] - last_time
        
        # If we moved forward in time, add skips
        while dt > 0:
            step = min(dt, MAX_INT_VAL)
            tokens.append(TOK_SKIP)
            tokens.extend(ms_to_tokens(step))
            dt -= step
            # last_time += step

        # Handle Events
        if event['type'] == 'instr':
            # Only emit if it changed (optimization, optional but good for tokens)
            if event['data'] != last_instr:
                tokens.append(TOK_INSTR)
                tokens.append(event['data'])
                last_instr = event['data']
                last_time = event['time']
        
        elif event['type'] == 'note':
            tokens.append(event['note'])
            tokens.extend(ms_to_tokens(event['duration']))
            last_time = event['time']

    tokens.append(TOK_END)
    return tokens

def tokens_to_midi(tokens, output_path):
    """
    Decodes the token sequence back into a MIDI file.
    """
    mid = mido.MidiFile()
    track = mido.MidiTrack()
    mid.tracks.append(track)
    
    # Setup standard ticks
    mid.ticks_per_beat = 480
    tempo_bpm = 120
    tempo_us = 500000 # 120 BPM
    
    # Helper to convert ms to ticks at fixed 120 BPM
    # 1 beat = 500ms = 480 ticks => 1ms = 0.96 ticks
    def ms_to_ticks(ms):
        return int(ms * (mid.ticks_per_beat / (tempo_us / 1000000.0) / 1000.0))

    # Helper to clean up pending Note Offs
    # We store pending note offs as absolute tick times
    pending_note_offs = [] # List of (abs_tick, note_val, channel)
    
    current_abs_tick = 0
    current_instr = 0
    
    # We process tokens linearly
    i = 0
    
    # Skip start token and ID if present (logic handles stripping them before calling this usually, 
    # but we check just in case)
    if i < len(tokens) and tokens[i] == TOK_START:
        i += 2 # Skip start and track ID
    
    while i < len(tokens):
        token = tokens[i]
        
        if token == TOK_END:
            break
            
        # Before processing a new event token, we must check if we need to emit Note Offs
        # that should happen at the current time.
        # However, Mido tracks use delta times. 
        # The easiest way is to build a list of all events (On/Off) with absolute times, 
        # sort them, and then write to track.
        
        if token == TOK_SKIP:
            if i + 2 >= len(tokens): break
            h, l = tokens[i+1], tokens[i+2]
            ms = tokens_to_ms(h, l)
            i += 3
            
            # Advance time
            current_abs_tick += ms_to_ticks(ms)
            
        elif token == TOK_INSTR:
            if i + 1 >= len(tokens): break
            instr_id = tokens[i+1]
            i += 2
            # We record this as an event at current time
            # For simplicity in this linear pass, we'll just queue it.
            # But wait, we need a robust way to mix Note Ons and Note Offs.
            
            # Let's Restart the approach for writing:
            # 1. Parse tokens into a list of "Abstract Events"
            # 2. Convert Abstract Events into MIDI Messages
            pass # We will handle this in the "better approach" below
            
        elif token < 128: # Note
            if i + 2 >= len(tokens): break
            note_val = token
            len_h, len_l = tokens[i+1], tokens[i+2]
            duration_ms = tokens_to_ms(len_h, len_l)
            i += 3
            pass # Handle below
        else:
            i += 1 # Unknown token
            
    # --- Better Write Strategy ---
    # Reread tokens and build an absolute-time event list
    
    all_events = [] # (abs_tick, type, data...)
    curr_tick = 0
    
    i = 0
    if i < len(tokens) and tokens[i] == TOK_START:
        i += 2

    while i < len(tokens):
        token = tokens[i]
        
        if token == TOK_END:
            break
            
        if token == TOK_SKIP:
            if i+2 >= len(tokens): break
            ms = tokens_to_ms(tokens[i+1], tokens[i+2])
            curr_tick += ms_to_ticks(ms)
            i += 3
            
        elif token == TOK_INSTR:
            if i+1 >= len(tokens): break
            all_events.append((curr_tick, 'program_change', tokens[i+1]))
            i += 2
            
        elif token < 128: # Note
            if i+2 >= len(tokens): break
            duration_ms = tokens_to_ms(tokens[i+1], tokens[i+2])
            duration_ticks = ms_to_ticks(duration_ms)
            
            # Note On
            all_events.append((curr_tick, 'note_on', token))
            # Note Off
            all_events.append((curr_tick + duration_ticks, 'note_off', token))
            i += 3
        else:
            i += 1

    # Sort events: 1. Time, 2. Type preference (Offs before Ons, Program changes first)
    # Order: ProgramChange, NoteOff, NoteOn
    def type_priority(t):
        if t == 'program_change': return 0
        if t == 'note_off': return 1
        if t == 'note_on': return 2
        return 3

    all_events.sort(key=lambda x: (x[0], type_priority(x[1])))
    
    # Write to Mido Track using Delta Times
    last_tick = 0
    for evt in all_events:
        abs_tick, e_type, data = evt
        delta = abs_tick - last_tick
        last_tick = abs_tick
        
        if e_type == 'program_change':
            track.append(mido.Message('program_change', program=data, time=delta))
        elif e_type == 'note_on':
            track.append(mido.Message('note_on', note=data, velocity=127, time=delta))
        elif e_type == 'note_off':
            track.append(mido.Message('note_off', note=data, velocity=0, time=delta))
            
    mid.save(output_path)
    print(f"Saved MIDI to {output_path}")

# --- AI Logic (Modified from your script) ---

def train_model(source_folder, model_path, context_length=64, pruning_threshold=0):
    print("Starting model training...")
    files = glob.glob(os.path.join(source_folder, "*.mid"))
    if not files:
        raise FileNotFoundError("No MIDI files found")

    # Dictionary to store File ID -> Filename mapping
    id_map = {}
    
    # Concatenated stream of all training data
    full_token_stream = []

    for idx, fpath in enumerate(files):
        track_id = idx % 128 # Wrap around if > 127, or we could use larger tokens
        id_map[track_id] = os.path.basename(fpath)
        
        tokens = parse_midi_to_tokens(fpath, track_id)
        full_token_stream.extend(tokens)

    for tid, fname in id_map.items():
        print(f"ID {tid}: {fname}")

    # model: {context_len: {context_tuple: {next_token: count}}}
    model = {i: defaultdict(lambda: defaultdict(int)) for i in range(1, context_length + 1)}
    
    tokens = full_token_stream
    for i in trange(len(tokens) - 1, unit="tok", unit_scale=True, dynamic_ncols=True):
        for j in range(1, context_length + 1):
            if i >= j - 1:
                context_key = tuple(tokens[i - j + 1 : i + 1])
                next_token = tokens[i + 1]
                model[j][context_key][next_token] += 1

    if pruning_threshold > 0:
        print(f"Pruning model...")
        for length in range(1, context_length + 1):
            keys_to_delete = []
            for context_key, outcomes in model[length].items():
                total_count = sum(outcomes.values())
                if total_count <= pruning_threshold + 1:
                    if outcomes:
                        most_common_next_token = max(outcomes, key=outcomes.get)
                        model[length][context_key] = defaultdict(int)
                        model[length][context_key][most_common_next_token] = outcomes[most_common_next_token]

    print("Training complete. Writing model...")
    with open(model_path, 'wb') as f:
        # Save both the model and the ID map
        regular_model = {length: {k: dict(v) for k, v in sub.items()} for length, sub in model.items()}
        pickle.dump((regular_model, id_map), f)
    print("Done.")

def generate_music(model_path, output_midi, track_id=None, max_tokens=10000, context_length=None):
    print("Loading model...")
    with open(model_path, 'rb') as f:
        data = pickle.load(f)
        if isinstance(data, tuple):
            model, id_map = data
        else:
            model = data # Legacy support just in case
            id_map = {}

    if not context_length: 
        context_length = max(model.keys())

    # Start Sequence
    generated_tokens = [TOK_START]
    
    if track_id is not None:
        if id_map.get(track_id) == None:
            raise ValueError("Unknown track ID")
        else:
            generated_tokens.append(track_id)
    else:
        # Let the model pick the ID based on [TOK_START]
        pass 

    print("Generating tokens...")
    for _ in range(max_tokens):
        # Stop if we hit end
        if generated_tokens[-1] == TOK_END:
            break

        found_match = False
        # Try largest context first
        for i in range(context_length, 0, -1):
            if len(generated_tokens) < i:
                continue
            
            context = tuple(generated_tokens[-i:])
            if context in model[i]:
                outcomes = model[i][context]
                choices = list(outcomes.keys())
                weights = list(outcomes.values())
                next_tok = random.choices(choices, weights, k=1)[0]
                generated_tokens.append(next_tok)
                found_match = True
                break
        
        if not found_match:
            # Fallback: Pick random token based on unigrams (model[1])
            # Or just pick a random note if completely lost
            if 1 in model and model[1]:
                rand_ctx = random.choice(list(model[1].keys()))
                outcomes = model[1][rand_ctx]
                next_tok = random.choices(list(outcomes.keys()), list(outcomes.values()), k=1)[0]
                generated_tokens.append(next_tok)
            else:
                break

    print(f"Generated {len(generated_tokens)} tokens.")
    tokens_to_midi(generated_tokens, output_midi)

if __name__ == "__main__":
    # Configuration
    MODEL_FILE = "music_model.bin"
    TRAINING_DIR = "./midi_samples" # Create this folder and put MIDIs in it
    OUTPUT_FILE = "ai_music.mid"
    
    # 1. Train
    if not os.path.exists(TRAINING_DIR):
        pass
    else:
        if False: train_model(TRAINING_DIR, MODEL_FILE, context_length=32)
    
    # 2. Generate
    if os.path.exists(MODEL_FILE):
         generate_music(MODEL_FILE, OUTPUT_FILE, track_id=2, max_tokens=100000, context_length=16)
    else:
         print("Model not found. Please train first.")