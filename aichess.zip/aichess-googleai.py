try:
  # Import chess modules
  import chess
  import chess.pgn
except ModuleNotFoundError as e:
  raise ModuleNotFoundError(str(e) + "\n\nFatal Error: Could not find chess module. Is it installed?\n\nIf not, install it through the following command:\npip install chess").with_traceback(e.__traceback__) from e
try:
  from google import genai # Import genai module
except ModuleNotFoundError as e:
  raise ModuleNotFoundError(str(e) + "\n\nFatal Error: Could not find google-genai module. Is it installed?\n\nIf not, install it through the following command:\npip install google-genai").with_traceback(e.__traceback__) from e
import json # Import json module
from getpass import getpass # Import getpass module

def ai_move(board): # Play an AI move
  # Make list of legal SAN moves
  moves = []
  for move in board.legal_moves: moves += [board.san(move)]

  if c == "Y" or c == "y":
    if board.turn: # Select correct AI and Schema properties
      llm = wm
      properties = {"move":{"description":"The AI's (White) move to play.","type":"string","enum":moves},"move_commentary":{"description":"Commentary for the AI's (White) played move.","type":"string"}}
    else:
      llm = bm
      properties = {"move":{"description":"The AI's (Black) move to play.","type":"string","enum":moves},"move_commentary":{"description":"Commentary for the AI's (Black) played move.","type":"string"}}
    required = ["move", "move_commentary"]
  else:
    if board.turn: # Select correct AI and Schema properties
      llm = wm
      properties = {"move":{"description":"The AI's (White) move to play.","type":"string","enum":moves}}
    else:
      llm = bm
      properties = {"move":{"description":"The AI's (Black) move to play.","type":"string","enum":moves}}
    required = ["move"]
  try:
    move = board.peek()
    board.pop()
    if board.is_en_passant(move):
      display_move = board.san(move) + " (en passant)"
    elif board.is_capture(move):
      if board.piece_type_at(move.to_square) == chess.PAWN: display_move = board.san(move) + " (pawn capture)"
      if board.piece_type_at(move.to_square) == chess.KNIGHT: display_move = board.san(move) + " (knight capture)"
      if board.piece_type_at(move.to_square) == chess.BISHOP: display_move = board.san(move) + " (bishop capture)"
      if board.piece_type_at(move.to_square) == chess.ROOK: display_move = board.san(move) + " (rook capture)"
      if board.piece_type_at(move.to_square) == chess.QUEEN: display_move = board.san(move) + " (queen capture)"
    else:
      display_move = board.san(move)
    board.push(move)
    string = new_board(board) + "Opponent's move: " + display_move + ("\nWhite to move" if board.turn else "\nBlack to move") + ("\nKing is in check" if board.is_check() else "")
  except IndexError:
    string = new_board(board) + ("\nWhite to move" if board.turn else "\nBlack to move") + ("\nKing is in check" if board.is_check() else "")

  schema = { # Make JSON Schema
    "title": "Chess",
    "type": "object",
    "properties": properties,
    "required": required
  }

  response = json.loads(client.models.generate_content(model=llm,contents=string,config={"response_mime_type":"application/json","response_schema":schema}).text) # Make a string response following the Schema as JSON

  if c == "Y" or c == "y":
    return response["move"], response["move_commentary"] # Return move and move commentary
  else:
    return response["move"] # Return move

def new_board(board): # Better board display implementation with coordinates
  x = ""
  for i, line in enumerate(str(board).split('\n')): x += f"{8 - i} {line}\n"
  x += "  a b c d e f g h"
  return x

key = getpass("Input your API key (leave blank if you don't have one to learn how to get one): ")
if not key: raise ValueError("If you don't have an API key, go to https://aistudio.google.com/app/apikey and get yourself a legitimate and free API key. And don't forget to check https://ai.google.dev/gemini-api/docs/rate-limits#free-tier as well for rate limits.")
w = input("Should White be controlled by AI [Y/N]? ") # Select AI for White
wm = input("Select model (leave blank to pick gemini-2.5-flash-lite): ")
b = input("Should Black be controlled by AI [Y/N]? ") # Select AI for Black
bm = input("Select model (leave blank to pick gemini-2.5-flash-lite): ")
c = input("Enable AI commentary [Y/N]? ") # Select commentary
fen = input("Specify a FEN (leave blank for starting position): ") # Specify FEN

client = genai.Client(api_key=key)
# You can use better models, but for an average user with a free tier API key, to respect rate limits, gemini-2.5-flash-lite is good enough. However, if you really want to, gemini-2.5-flash or even gemini-2.5-pro can be worth it.
if not wm: wm = "gemini-2.5-flash-lite"
if not bm: bm = "gemini-2.5-flash-lite"

game = chess.pgn.Game() # Initialize chess PGN
if fen:
  try:
    board = chess.Board(fen) # Initialize chess game
    game.setup(fen) # Setup position
  except ValueError as e:
    raise ValueError("Invalid FEN:" + str(e))
else:
  board = chess.Board() # Initialize chess game
node = game # Initialize chess PGN

changed = True

while True: # Main logic
  if changed: # Print chess board and properties
    print((f"\nMove {board.fullmove_number}.\n" if board.turn else f"\nMove {board.fullmove_number}...\n") + new_board(board) + ("\nWhite to move" if board.turn else "\nBlack to move") + ("\nKing is in check" if board.is_check() else ""))
    changed = False
  if board.is_game_over(claim_draw=True): # Show game over screen and finalize PGN
    print("\nGAME OVER!")
    if board.outcome(claim_draw=True).termination == chess.Termination.CHECKMATE:
      print("White wins by checkmate" if board.outcome().winner else "Black wins by checkmate")
    if board.outcome(claim_draw=True).termination == chess.Termination.STALEMATE:
      print("Draw by stalemate")
    if board.outcome(claim_draw=True).termination == chess.Termination.INSUFFICIENT_MATERIAL:
      print("Draw by insufficient material")
    if board.outcome(claim_draw=True).termination == chess.Termination.FIFTY_MOVES:
      print("Draw by fifty move rule")
    if board.outcome(claim_draw=True).termination == chess.Termination.THREEFOLD_REPETITION:
      print("Draw by threefold repetition")
    print("\nPGN:")
    game.headers["Result"] = board.result(claim_draw=True)
    print(game)
    break
  if board.turn and (w == "Y" or w == "y"): # AI move for White
    print()
    if c == "Y" or c == "y":
      move, move_commentary = ai_move(board)
      print("AI move: " + move)
      print("AI move commentary: " + move_commentary)
      board.push_san(move)
      node = node.add_variation(board.peek())
      node.comment = move_commentary
    else:
      move = ai_move(board)
      print("AI move: " + move)
      board.push_san(move)
      node = node.add_variation(board.peek())
    changed = True
    continue
  if not board.turn and (b == "Y" or b == "y"): # AI move for Black
    print()
    if c == "Y" or c == "y":
      move, move_commentary = ai_move(board)
      print("AI move: " + move)
      print("AI move commentary: " + move_commentary)
      board.push_san(move)
      node = node.add_variation(board.peek())
      node.comment = move_commentary
    else:
      move = ai_move(board)
      print("AI move: " + move)
      board.push_san(move)
      node = node.add_variation(board.peek())
    changed = True
    continue
  choice = input("Select a choice: ")
  try:
    if choice == "back": # Go back to a previous move
      board.pop()
      node.parent.remove_variation(0)
      node = node.parent
      changed = True
      continue
  except IndexError as e:
    print("Error: No previous move: " + str(e))
    continue
  try:
    if choice == "peek": # See the previous move
      move = board.peek()
      board.pop()
      print(board.san(move))
      board.push(move)
      continue
  except IndexError as e:
    print("Error: No previous move: " + str(e))
    continue
  if choice == "ai": # Suggest AI move for Human
    if c == "Y" or c == "y":
      move, move_commentary = ai_move(board)
      print("Suggested AI move: " + move)
      print("Suggested AI move commentary: " + move_commentary)
    else:
      move = ai_move(board)
      print("Suggested AI move: " + move)
    continue
  if choice == "pgn": # Show PGN
    print(game)
    continue
  try:
    if board.parse_san(choice): # Make a move
      board.push(board.parse_san(choice))
      node = node.add_variation(board.peek())
      changed = True
      continue
  except chess.InvalidMoveError as e:
    print("Error: Syntactically invalid move or command: " + str(e))
    continue
  except chess.IllegalMoveError as e:
    print("Error: Illegal move: " + str(e))
    continue
  except chess.AmbiguousMoveError as e:
    print("Error: Ambiguous move: " + str(e))
    continue