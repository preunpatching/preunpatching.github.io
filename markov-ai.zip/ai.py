import pickle
import random
from collections import defaultdict
import tiktoken
from tqdm import trange

def train_model(source_path, model_path, context_length=2, encoding="o200k_harmony", pruning_threshold=0):
    """Trains a text generation model with an adjustable context length and optional pruning."""
    print("Starting model training...")
    if context_length < 1:
        print("Error: context_length must be 1 or greater.")
        return
    try:
        with open(source_path, 'r', encoding='utf-8') as f:
            text = f.read()
    except FileNotFoundError:
        print(f"Error: The file '{source_path}' was not found.")
        return
    encoding = tiktoken.get_encoding(encoding)
    tokens = encoding.encode(text)
    model = {i: defaultdict(lambda: defaultdict(int)) for i in range(1, context_length + 1)}
    for i in trange(len(tokens) - 1, unit="tok", unit_scale=True, dynamic_ncols=True):
        for j in range(1, context_length + 1):
            if i >= j:
                context_key = tuple(tokens[i - j + 1 : i + 1])
                next_token = tokens[i + 1]
                model[j][context_key][next_token] += 1
    if pruning_threshold > 0:
        print(f"Pruning model...")
        for length in range(1, context_length + 1):
            keys_to_delete = []
            for context_key, outcomes in model[length].items():
                total_count = sum(outcomes.values())
                if total_count <= pruning_threshold + 1:
                    if outcomes:
                        most_common_next_token = max(outcomes, key=outcomes.get)
                        model[length][context_key] = defaultdict(int)
                        model[length][context_key][most_common_next_token] = outcomes[most_common_next_token]
    print("Training complete. Writing model...")
    with open(model_path, 'wb') as f:
        regular_model = {length: dict(sub_model) for length, sub_model in model.items()}
        for sub_model in regular_model.values():
            for key in sub_model:
                sub_model[key] = dict(sub_model[key])
        pickle.dump(regular_model, f)
    print("Done.")

def generate_text(model_path, start_phrase, num_tokens, encoding="o200k_harmony", context_length=None):
    """Generates text from a pickled model."""
    print("Loading model...")
    with open(model_path, 'rb') as f:
        model = pickle.load(f)
    print("Generating text...")
    encoding = tiktoken.get_encoding(encoding)
    if not context_length: context_length = max(model.keys())
    generated_tokens = encoding.encode(start_phrase)
    for _ in range(num_tokens):
        found_match = False
        for i in range(context_length, 0, -1):
            if len(generated_tokens) < i:
                continue
            context_tokens = tuple(generated_tokens[-i:])
            if context_tokens in model[i]:
                possible_outcomes = model[i][context_tokens]
                choices = list(possible_outcomes.keys())
                weights = list(possible_outcomes.values())
                next_token = random.choices(choices, weights, k=1)[0]
                generated_tokens.append(next_token)
                found_match = True
                break
        if not found_match:
            random_key = random.choice(list(model[1].keys()))
            possible_outcomes = model[1][random_key]
            choices = list(possible_outcomes.keys())
            weights = list(possible_outcomes.values())
            next_token = random.choices(choices, weights, k=1)[0]
            generated_tokens.append(next_token)
    return encoding.decode(generated_tokens)

if __name__ == "__main__":
    # Example usage:
    encoding = "o200k_harmony"
    file = "model.bin"
    
    # 1. Train the model.
    context_length_to_use = 5
    train_model("train.txt", file, context_length=context_length_to_use, encoding=encoding, pruning_threshold=0)
    
    # 2. Generate text.
    start_phrase = ""
    num_tokens_to_generate = 300
    
    generated_text = generate_text(file, start_phrase, num_tokens_to_generate, encoding=encoding, context_length=context_length_to_use)
    
    print(generated_text)